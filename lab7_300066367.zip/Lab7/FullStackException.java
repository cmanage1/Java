public class FullStackException extends IllegalStateException{

    public FullStackException(String messege){
        super(messege);    
    }
}
