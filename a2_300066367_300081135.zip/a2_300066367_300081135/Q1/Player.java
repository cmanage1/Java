public interface Player{

    public abstract void play(TicTacToeGame game);

    

}
