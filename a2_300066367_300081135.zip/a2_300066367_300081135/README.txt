Kaitlyn DomPaul 300081135  C01
Chethin Manage 300066367 D01

Assignment 2, folders Q1 Q2 Q3
