Student name: Chethin Manage
Student number: 300066367
Course code: ITI1121
Lab section: D-01

This archive contains the 3 files of the lab 3, that is, this file (README.txt),
plus the files Utils.java and Rational.java.
