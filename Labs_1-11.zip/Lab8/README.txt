Student name: Chethin Manage
Student number: 300066367
Course code: ITI1121
Lab section: D-01

This archive contains the 5 files of lab 8, that is, this file (README.txt),
plus Queue.java, ArrayQueue.java, Customer.java, Cashier.java.
