Student name: Jane Doe
Student number: 3000
Course code: 12345
Lab section: D-1

This archive contains the 3 files of the lab 2, that is, this file (README.txt),
plus the files Combination.java and DoorLock.java.
