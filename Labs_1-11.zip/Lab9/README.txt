Student name: Jane Doe
Student number: 123456
Course code: ITI1121
Lab section: B-2

This archive contains the 7 files of lab 9, that is, this file (README.txt),
plus SecretMessage.java, PlayList.java, Song.java, SortByAlbum.java, SortByArtist.java, SortByName.java.

 