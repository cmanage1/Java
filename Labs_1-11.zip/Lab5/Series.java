public interface Series {

    public double next();

}
