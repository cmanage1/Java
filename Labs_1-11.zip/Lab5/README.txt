Student name: Chethin Manage
Student number: 300066367
Course code: ITI1121
Lab section: D-1

This archive contains the 8 files of lab 5, that is, this file (README.txt),
plus Book.java, Library.java, BookComparator.java, Series.java, AbstractSeries.java, Arithmetic.java, Geometric.java.
